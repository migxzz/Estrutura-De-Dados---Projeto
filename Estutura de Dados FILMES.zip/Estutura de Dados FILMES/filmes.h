#ifndef FILMES_H
#define FILMES_H

#define SUCESSO 0
#define ERRO 1


typedef struct Filme {
    char titulo[100];
    int anoLancamento;
    struct Filme* anterior;
    struct Filme* proximo;
} Filme;


typedef struct ListaReproducao {
    Filme* inicio;
} ListaReproducao;


typedef struct PilhaFilmesAssistidos {
    Filme* topo;
} PilhaFilmesAssistidos;


void inicializarListaReproducao(ListaReproducao* lista);
void adicionarFilme(ListaReproducao* lista, char* titulo, int anoLancamento);
void exibirListaReproducao(ListaReproducao* lista);
void inserirDepois(ListaReproducao* lista, char* tituloExistente, char* novoTitulo, int novoAnoLancamento);
void inserirAntes(ListaReproducao* lista, char* tituloExistente, char* novoTitulo, int novoAnoLancamento);

int removerFilme(ListaReproducao* lista, char* titulo);
Filme* buscarFilme(ListaReproducao* lista, char* titulo);


void inicializarPilhaFilmesAssistidos(PilhaFilmesAssistidos* pilha);
void assistirFilme(PilhaFilmesAssistidos* pilha, char* titulo, int anoLancamento);
void desfazerAssistirFilme(PilhaFilmesAssistidos* pilha);
void exibirFilmesAssistidos(PilhaFilmesAssistidos* pilha);

int contarFilmes(ListaReproducao* lista);

#endif

