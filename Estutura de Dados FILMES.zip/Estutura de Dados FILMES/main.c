#include <stdio.h>
#include <stdlib.h>
#include "filmes.h"

int main() {
    ListaReproducao lista;
    PilhaFilmesAssistidos pilha;
    int opcao;
    char nome[100];
    int anoLancamento;
    Filme* filmeAtual = NULL;
	char novoNome[100];
	int novoAnoLancamento;
	char nomeExistente[100];

    inicializarListaReproducao(&lista);
    inicializarPilhaFilmesAssistidos(&pilha);

    do {
        printf(" _____________________________ \n");
        printf("| 0 Fim                       |\n");
        printf("| 1 Adicionar filme a Lista   |\n");
        printf("| 2 Exibir Lista              |\n");
        printf("| 3 Remover Filme da Lista    |\n");
        printf("| 4 Inserir na pilha          |\n");
        printf("| 5 Remover da pilha          |\n");
        printf("| 6 Exibir Pilha              |\n");
        printf("| 7 Ultimo filme assistido    |\n");
        printf("| 8 Inserir Depois na Lista   |\n");
        printf("| 9 Inserir Antes na Lista   |\n");
        printf("|_____________________________|\n");
        printf("Escolha uma opcao: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Informe o nome do filme: ");
                scanf("%s", nome);
                printf("Informe o ano de lancamento: ");
                scanf("%d", &anoLancamento);
                adicionarFilme(&lista, nome, anoLancamento);
                printf("Filme adicionado.\n");
                break;

            case 2:
                exibirListaReproducao(&lista);
                break;

            case 3:
                printf("Informe o nome do filme a ser removido: ");
				scanf("%s", nome);
                removerFilme(&lista, nome);
                break;

            case 4:
                printf("Informe o nome do filme a ser adicionado na pilha: ");
                scanf("%s", nome);
                printf("Informe o ano de lancamento: ");
                scanf("%d", &anoLancamento);
                assistirFilme(&pilha, nome, anoLancamento);
                printf("Filme adicionado a Pilha de assistidos!\n");
                break;

            case 5:
                desfazerAssistirFilme(&pilha);
                printf("Filme removido da pilha de assistidos!\n");
                break;

            case 6:
                exibirFilmesAssistidos(&pilha);
                break;

            case 7:
                if (pilha.topo != NULL) {
                    printf("Ultimo filme assistido: %s (%d)\n", pilha.topo->titulo, pilha.topo->anoLancamento);
                } else {
                    printf("Nenhum filme foi assistido ainda.\n");
                }
                break;

            case 0:
                printf("Encerrando o programa.\n");
                break;
                
            case 8:
        		printf("Informe o titulo do filme existente: ");
        		scanf("%s", nomeExistente);

        		printf("Informe o titulo do novo filme: ");
        		scanf("%s", novoNome);

        		printf("Informe o ano de lancamento do novo filme: ");
        		scanf("%d", &novoAnoLancamento);

        		inserirDepois(&lista, nomeExistente, novoNome, novoAnoLancamento);
        		break;
        	
        	case 9:
    			printf("Informe o titulo do filme existente: ");
    			scanf("%s", nomeExistente);

   				printf("Informe o titulo do novo filme: ");
    			scanf("%s", novoNome);

    			printf("Informe o ano de lancamento do novo filme: ");
    			scanf("%d", &novoAnoLancamento);

    			inserirAntes(&lista, nomeExistente, novoNome, novoAnoLancamento);
    			break;

            default:
                printf("Op��o invalida. Tente novamente.\n");
        }
    } while (opcao != 0);

    return 0;
}

