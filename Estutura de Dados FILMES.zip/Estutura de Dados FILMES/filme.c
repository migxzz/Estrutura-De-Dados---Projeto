#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filmes.h"


void inicializarListaReproducao(ListaReproducao* lista) {
    lista->inicio = NULL;
}

void adicionarFilme(ListaReproducao* lista, char* titulo, int anoLancamento) {
    Filme* novoFilme = (Filme*)malloc(sizeof(Filme));
    if (novoFilme == NULL) {
        printf("Erro: Falha ao alocar memoria para o novo filme.\n");
        return;
    }

    strcpy(novoFilme->titulo, titulo);
    novoFilme->anoLancamento = anoLancamento;
    novoFilme->anterior = NULL;
    novoFilme->proximo = lista->inicio;

    if (lista->inicio != NULL) {
        lista->inicio->anterior = novoFilme;
    }

    lista->inicio = novoFilme;
}

void exibirListaReproducao(ListaReproducao* lista) {
    Filme* atual = lista->inicio;

    if (atual == NULL) {
        printf("Lista de reprodu?ao vazia.\n");
        return;
    }

    printf("Lista de Reprodu?ao:\n");

    while (atual != NULL) {
        printf("%s (%d)\n", atual->titulo, atual->anoLancamento);
        atual = atual->proximo;
    }
    printf("\n");
}


int removerFilme(ListaReproducao* lista, char* titulo) {
    Filme* atual = lista->inicio;

    while (atual != NULL) {
        if (strcmp(atual->titulo, titulo) == 0) {

            if (atual->anterior != NULL) {
                atual->anterior->proximo = atual->proximo;
            } else {
   
                lista->inicio = atual->proximo;
            }

            if (atual->proximo != NULL) {
                atual->proximo->anterior = atual->anterior;
            }

            free(atual);
            printf("Filme \"%s\" removido com sucesso.\n", titulo);
            return SUCESSO;
        }

        atual = atual->proximo;
    }

    
    printf("Erro: Filme \"%s\" nao encontrado na lista de reprodu?ao.\n", titulo);
    return ERRO;
}

Filme* buscarFilme(ListaReproducao* lista, char* titulo) {
    Filme* atual = lista->inicio;

    while (atual != NULL) {
        if (strcmp(atual->titulo, titulo) == 0) {
            return atual;
        }
        atual = atual->proximo;
    }

    printf("Erro: Filme \"%s\" n?o encontrado na lista de reproducao.\n", titulo);
    return NULL;
}


void inicializarPilhaFilmesAssistidos(PilhaFilmesAssistidos* pilha) {
    pilha->topo = NULL;
}

void assistirFilme(PilhaFilmesAssistidos* pilha, char* titulo, int anoLancamento) {
    Filme* novoFilme = (Filme*)malloc(sizeof(Filme));
    if (novoFilme == NULL) {
        printf("Erro: Falha ao alocar memoria para o novo filme assistido.\n");
        return;
    }

    strcpy(novoFilme->titulo, titulo);
    novoFilme->anoLancamento = anoLancamento;
    novoFilme->anterior = NULL;
    novoFilme->proximo = pilha->topo;

    if (pilha->topo != NULL) {
        pilha->topo->anterior = novoFilme;
    }

    pilha->topo = novoFilme;
}

void desfazerAssistirFilme(PilhaFilmesAssistidos* pilha) {
    if (pilha->topo == NULL) {
        printf("A pilha de filmes assistidos est? vazia.\n");
        return;
    }

    Filme* filmeRemovido = pilha->topo;
    pilha->topo = filmeRemovido->proximo;

    free(filmeRemovido);
}

void exibirFilmesAssistidos(PilhaFilmesAssistidos* pilha) {
    Filme* atual = pilha->topo;

    if (atual == NULL) {
        printf("Pilha de Filmes Assistidos est? vazia.\n");
        return;
    }

    printf("Filmes Assistidos:\n");

    while (atual != NULL) {
        printf("%s (%d)\n", atual->titulo, atual->anoLancamento);
        atual = atual->proximo;
    }
    printf("\n");
}

int contarFilmes(ListaReproducao* lista) {
    int contador = 0;
    Filme* atual = lista->inicio;

    while (atual != NULL) {
        contador++;
        atual = atual->proximo;
    }

    return contador;
}


void inserirDepois(ListaReproducao* lista, char* tituloExistente, char* novoTitulo, int novoAnoLancamento) {
    Filme* atual = lista->inicio;

    while (atual != NULL) {
        if (strcmp(atual->titulo, tituloExistente) == 0) {
            Filme* novoFilme = (Filme*)malloc(sizeof(Filme));
            if (novoFilme == NULL) {
                printf("Erro: Falha ao alocar memoria para o novo filme.\n");
                return;
            }

            strcpy(novoFilme->titulo, novoTitulo);
            novoFilme->anoLancamento = novoAnoLancamento;

            novoFilme->anterior = atual;
            novoFilme->proximo = atual->proximo;

            if (atual->proximo != NULL) {
                atual->proximo->anterior = novoFilme;
            }

            atual->proximo = novoFilme;

            printf("Filme \"%s\" inserido com sucesso depois de \"%s\".\n", novoTitulo, tituloExistente);
            return;
        }

        atual = atual->proximo;
    }

    printf("Erro: Filme \"%s\" n�o encontrado na lista de reproducao.\n", tituloExistente);
}

void inserirAntes(ListaReproducao* lista, char* tituloExistente, char* novoTitulo, int novoAnoLancamento) {
    Filme* atual = lista->inicio;

    while (atual != NULL) {
        if (strcmp(atual->titulo, tituloExistente) == 0) {
            Filme* novoFilme = (Filme*)malloc(sizeof(Filme));
            if (novoFilme == NULL) {
                printf("Erro: Falha ao alocar memoria para o novo filme.\n");
                return;
            }

            strcpy(novoFilme->titulo, novoTitulo);
            novoFilme->anoLancamento = novoAnoLancamento;

            novoFilme->anterior = atual->anterior;
            novoFilme->proximo = atual;

            if (atual->anterior != NULL) {
                atual->anterior->proximo = novoFilme;
            } else {
                lista->inicio = novoFilme;
            }

            atual->anterior = novoFilme;

            printf("Filme \"%s\" inserido com sucesso antes de \"%s\".\n", novoTitulo, tituloExistente);
            return;
        }

        atual = atual->proximo;
    }

    printf("Erro: Filme \"%s\" n�o encontrado na lista de reproducao.\n", tituloExistente);
}





